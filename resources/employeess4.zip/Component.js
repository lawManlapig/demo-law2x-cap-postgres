sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("employeess4.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map